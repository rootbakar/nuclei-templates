|    TAG    | COUNT |    AUTHOR     | COUNT | DIRECTORY  | COUNT | SEVERITY | COUNT | TYPE | COUNT |
|-----------|-------|---------------|-------|------------|-------|----------|-------|------|-------|
| cve       |  2604 | dhiyaneshdk   |  1360 | http       |  7723 | info     |  3802 | file |   402 |
| panel     |  1173 | daffainfo     |   864 | file       |   402 | high     |  1843 | dns  |    25 |
| wordpress |  1008 | dwisiswant0   |   803 | workflows  |   192 | medium   |  1588 |      |       |
| exposure  |   971 | pussycat0x    |   447 | network    |   137 | critical |  1083 |      |       |
| xss       |   919 | ritikchaddha  |   393 | cloud      |   134 | low      |   272 |      |       |
| wp-plugin |   878 | pikpikcu      |   353 | code       |    81 | unknown  |    41 |      |       |
| osint     |   805 | princechaddha |   303 | javascript |    61 |          |       |      |       |
| tech      |   703 | pdteam        |   297 | ssl        |    29 |          |       |      |       |
| lfi       |   685 | ricardomaia   |   241 | dast       |    25 |          |       |      |       |
| misconfig |   678 | geeknik       |   231 | dns        |    22 |          |       |      |       |
